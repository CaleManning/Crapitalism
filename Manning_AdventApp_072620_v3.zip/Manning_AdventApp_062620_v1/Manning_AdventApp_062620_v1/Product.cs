﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace Manning_AdventApp_062620_v1
{
    class Product
    {
        string name = "";
        double makeprice = 0;
        double sellprice = 0;
        public int invent = 0;
        int marketability = 50;
        //scale of 0 - 100
        public Product(string n, double p, int i, int m)
        {
            name = n;
            makeprice = p / 2;
            sellprice = p;
            invent = i;
            marketability = m;
        }
        //get
        public string getName()
        {
            return name;
        }
        public double getMakePrice()
        {
            return makeprice;
        }
        public string getMakePriceSTR()
        {
            return makeprice.ToString("C", CultureInfo.CurrentCulture);
        }
        public double getSellPrice()
        {
            return sellprice;
        }
        public string getSellPriceSTR()
        {
            return sellprice.ToString("C", CultureInfo.CurrentCulture);
        }
        public int getInventory()
        {
            return invent;
        }
        public int getMarketability()
        {
            return marketability;
        }
        //set
        public void setName(string n)
        {
            name = n;
        }
        //other
        public void productSetup(string n, double p, int i, int m)
        {
            name = n;
            makeprice = p / 2;
            sellprice = p;
            invent = i;
            marketability = m;
        }
    }
}
