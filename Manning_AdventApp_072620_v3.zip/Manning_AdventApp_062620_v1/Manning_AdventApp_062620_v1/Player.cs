﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Manning_AdventApp_062620_v1
{
    class Player
    {
        public int ruthlessness = 5;
        public int collaberative = 5;
        public int intelligence = 5;
        public int charisma = 5;
        public int extraPoints = 6;
        //all stats rated on a 0-10 scale
        public string name;
        public string buisness_name;

        public Player()
        {
        }
        //get methods
        public int getRuthlessness()
        {
            return ruthlessness;
        }
        public int getCollaberative()
        {
            return collaberative;
        }
        public int getIntelligence()
        {
            return intelligence;
        }
        public int getCharisma()
        {
            return charisma;
        }
        public string getName()
        {
            return name;
        }
        public string getBuisName()
        {
            return buisness_name;
        }
        //set methods

        //special methods
        public void characterSetup()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Welcome to");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(" Crapitalism!");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            Boolean moveon = false;
            while (moveon != true)
            {
                Console.WriteLine("Please enter what you want your characters name to be:");
                name = Console.ReadLine();
                if(name.Length > 0)
                {
                    moveon = true;
                }
                else
                {
                    Console.WriteLine("Well you can't be named nothing, press enter to try again.");
                    Console.ReadKey();
                }
                Console.Clear();
            }
            Console.WriteLine($"Welcome {name} to the wonderful world of Crapitalism!");
            Console.WriteLine("Before we go any deeper into the game it's clear you need to work on yourself!");
            Console.WriteLine("Press enter when you're ready to head to character setup.");
            Console.ReadKey();
            statSetup();
            Console.Clear();
            Console.WriteLine("You're already looking better than before!");
            Console.WriteLine("Now comes the most important part of running a buisness, picking the name.");
            moveon = false;
            while(moveon != true)
            {
                Console.WriteLine("What do you want your new coorporation to be called?");
                buisness_name = Console.ReadLine();
                if (buisness_name.Length > 0)
                {
                    moveon = true;
                }
                else
                {
                    Console.WriteLine("Well your buisness can't be called nothing, press enter to try again.");
                    Console.ReadKey();
                }
                Console.Clear();
            }
            Console.WriteLine("Very intresting, not exactly what I would have gone with but good enough!");
            Console.WriteLine("Let's get this buisness running! Press enter to start the game.");
            Console.ReadKey();
        }
        public void showStats()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"{name}'s Stats:");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Ruthlessness");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {ruthlessness}");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Collaborative");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {collaberative}");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Intelligence");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {intelligence}");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Charisma");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {charisma}");
            Console.WriteLine();
        }
        public void setupShowStats()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"{name}'s Stats:");
            Console.Write("a +, b -  ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Ruthlessness");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {ruthlessness}");
            Console.WriteLine();
            Console.Write("c +, d -  ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Collaborative");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {collaberative}");
            Console.WriteLine();
            Console.Write("e +, f -  ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Intelligence");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {intelligence}");
            Console.WriteLine();
            Console.Write("g +, h -  ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Charisma");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write($": {charisma}");
            Console.WriteLine();
        }
        public void statSetup()
        {
            Console.Clear();
            extraPoints = 6;
            ruthlessness = 5;
            collaberative = 5;
            intelligence = 5;
            charisma = 5;
            String ans = "";
            while(extraPoints > 0)
            {
                setupShowStats();
                Console.WriteLine("Pick which stat you want to add or subtract a point. The letters next to the pluses will add a point and the letters next to the minuses will take away a point. You can only put 10 total points into a skill.");
                Console.WriteLine("Extra Stats Left: " + extraPoints);
                ans = Console.ReadLine();
                checkSetupInput(ans.ToLower());
                Console.Clear();
            }
            Boolean breakout = false;
            while(breakout != true)
            {
                showStats();
                Console.WriteLine("Are you satisfied with these stats? (y or n)");
                ans = Console.ReadLine();
                if (ans.ToLower() == "y" || ans.ToLower() == "n" || ans.ToLower() == "no" || ans.ToLower() == "yes")
                {
                    breakout = true;
                }
                else
                {
                    Console.WriteLine("Please enter y or n. Press enter to try again.");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
            if(ans.ToLower() == "n" || ans.ToLower() == "no")
            {
                statSetup();
            }
        }
        public void checkSetupInput(string w)
        {
            if(w == "a" && ruthlessness != 10)
            {
                ruthlessness += 1;
                extraPoints -= 1;
            }
            else if(w == "b" && ruthlessness != 0)
            {
                ruthlessness -= 1;
                extraPoints += 1;
            }
            else if (w == "c" && collaberative != 10)
            {
                collaberative += 1;
                extraPoints -= 1;
            }
            else if (w == "d" && collaberative != 0)
            {
                collaberative -= 1;
                extraPoints += 1;
            }
            else if (w == "e" && intelligence != 10)
            {
                intelligence += 1;
                extraPoints -= 1;
            }
            else if (w == "f" && intelligence != 0)
            {
                intelligence -= 1;
                extraPoints += 1;
            }
            else if (w == "g" && charisma != 10)
            {
                charisma += 1;
                extraPoints -= 1;
            }
            else if (w == "h" && charisma != 0)
            {
                charisma -= 1;
                extraPoints += 1;
            }
        }
    }
}
