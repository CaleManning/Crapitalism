﻿/*
 * Cale Manning
 * isdigit foreach loop
 * Johnathan Wood on stackoverflow
 * URL: https://stackoverflow.com/questions/5026689/how-to-check-whether-a-string-in-net-is-a-number-or-not
 * Adventure Game : Crapitalism
 * 07/26/20
 * Version 3
 */
using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;

namespace Manning_AdventApp_062620_v1
{
    class Program
    {
        public static Player playerCharacter = new Player();
        public static Buisness playerBuis = new Buisness();
        public static List<EventMoney> ALLEVENTS = new List<EventMoney>();
        static void Main(string[] args)
        {
            Console.Title = ("Crapitalism!");
            playerCharacter.characterSetup();
            playerBuis.setName(playerCharacter.getBuisName());
            setupEvents();
            start();
        }
        public static void start()
        {
            String resp = "";
            Boolean breakpoint = false;
            Boolean turnbreakpoint = false;
            Boolean randEventcheck = false;
            int turns = 1;
            while (breakpoint != true)
            {
                while (turnbreakpoint != true)
                {
                    playerBuis.buisnessHeader();
                    Console.WriteLine("Turns: " + turns);
                    printopts();
                    resp = Console.ReadLine();
                    if (resp.ToLower() == "a")
                    {
                        playerBuis.listInventory();
                    }
                    else if (resp.ToLower() == "b")
                    {
                        playerBuis.newProduct();
                    }
                    else if (resp.ToLower() == "c")
                    {
                        Console.Clear();
                        if (randEventcheck == false)
                        {
                            getRandEvent();
                            randEventcheck = true;
                        }
                        else
                        {
                            Console.WriteLine("Sorry you can only do one random event per turn.");
                            Console.WriteLine("Press any key to continue.");
                            Console.ReadKey();
                        }
                    }
                    else if (resp.ToLower() == "d")
                    {
                        //player stat.
                        Console.Clear();
                        playerCharacter.showStats();
                        Console.WriteLine("Press any key to continue.");
                        Console.ReadKey();
                    }
                    else if (resp.ToLower() == "e")
                    {
                        //help
                        help();
                    }
                    else if (resp.ToLower() == "f")
                    {
                        turnbreakpoint = true;
                        playerBuis.sellInvent();
                    }
                    else if (resp.ToLower() == "g")
                    {
                        breakpoint = true;
                        turnbreakpoint = true;
                    }
                    Console.Clear();
                }
                if (playerBuis.loseTest() == true)
                {
                    Console.WriteLine("You're broke! Sorry but you've lost Crapitalism!");
                    turnbreakpoint = true;
                    breakpoint = true;
                    Console.WriteLine("Press any key to end the game");
                    Console.ReadKey();
                }
                randEventcheck = false;
                turnbreakpoint = false;
                turns += 1;
                Console.Clear();
            }
        }
        public static void printopts()
        {
            Console.WriteLine("A. Check Inventory");
            Console.WriteLine("B. Make New Product");
            Console.WriteLine("C. Start Random Event");
            Console.WriteLine("D. Check Player Stats");
            Console.WriteLine("E. Help");
            Console.WriteLine("F. Next Quarter");
            Console.WriteLine("G. End Game");
        }
        public static void setupEvents()
        {
            EventMoney ev1 = new EventMoney("A friend asks if you want to bet on a football game. You could win $100. Think you're smart enough to win the bet?", 100, "i");
            ALLEVENTS.Add(ev1);
            EventMoney ev2 = new EventMoney("Would you like to try to convince your grandma to give you some money for your brand new buisness?", 100, "ch");
            ALLEVENTS.Add(ev2);
            EventMoney ev3 = new EventMoney("Spend a weekend in Vegas and try to win big? $500 is on the line", 500, "i");
            ALLEVENTS.Add(ev3);
            EventMoney ev4 = new EventMoney("Think you can trick a rival company into selling you some of their stock?", 200, "r");
            ALLEVENTS.Add(ev4);
            EventMoney ev5 = new EventMoney("Tax evasion may be tricky but some would say it's worth it. Try your hand at it?", 200, "i");
            ALLEVENTS.Add(ev5);
            EventMoney ev6 = new EventMoney("Another company wants to try to work together on a large buisness event project. Think it's worth it?", 250, "co");
            ALLEVENTS.Add(ev6);
            EventMoney ev7 = new EventMoney("An employee piches you a new way of marketing your products. Think you can work with them on it?", 150, "co");
            ALLEVENTS.Add(ev7);
            EventMoney ev8 = new EventMoney("Some investors are a little hesitant to invest in your company. Think you can convince them?", 200, "ch");
            ALLEVENTS.Add(ev8);
            EventMoney ev9 = new EventMoney("A wealthy friend is intrested in investing in your company. Think you can convince them?", 150, "ch");
            ALLEVENTS.Add(ev9);
            EventMoney ev10 = new EventMoney("Want to try hiding some extra writeoffs for some extra cash?", 200, "i");
            ALLEVENTS.Add(ev10);
            EventMoney ev11 = new EventMoney("Political betting is a fun game, want to try betting on your favorite politician?", 200, "i");
            ALLEVENTS.Add(ev11);
            EventMoney ev12 = new EventMoney("Fire an employee to promote people to work harder?", 200, "r");
            ALLEVENTS.Add(ev12);
            EventMoney ev13 = new EventMoney("Short your rivals stock?", 200, "r");
            ALLEVENTS.Add(ev13);
            EventMoney ev14 = new EventMoney("Expand your employee base for a happier company?", 250, "co");
            ALLEVENTS.Add(ev14);
            EventMoney ev15 = new EventMoney("Want to invest in a local bar?", 100, "i");
            ALLEVENTS.Add(ev15);
            EventMoney ev16 = new EventMoney("Make a small commerical to promote your brand?", 200, "ch");
            ALLEVENTS.Add(ev16);
            EventMoney ev17 = new EventMoney("Bet on some horses! $500 is up for grabs!", 500, "i");
            ALLEVENTS.Add(ev17);
            EventMoney ev18 = new EventMoney("Leak some infromation about your rival to boost your brands PR?", 250, "r");
            ALLEVENTS.Add(ev18);
            EventMoney ev19 = new EventMoney("Will calling a bunch of people to advertise your brand help or hurt you?", 200, "co");
            ALLEVENTS.Add(ev19);
            EventMoney ev20 = new EventMoney("Try to get more investors for your company?", 300, "co");
            ALLEVENTS.Add(ev20);

            EventItem evi1 = new EventItem("Your friend offers you some old CD Players to sell should you take them?", "ch");
            evi1.setupWin("CD Player", 20, 3, 50);
            ALLEVENTS.Add(evi1);
            EventItem evi2 = new EventItem("You find an old TV in the trash, think you can repair it?", "i");
            evi2.setupWin("Old TV", 50, 1, 50);
            ALLEVENTS.Add(evi2);
            EventItem evi3 = new EventItem("Your grandmother offers you an awesome buisness deal selling radios, think you can work together?", "co");
            evi3.setupWin("Radio", 30, 10, 50);
            ALLEVENTS.Add(evi3);
            EventItem evi4 = new EventItem("Your stoner uncle passed away and left you some guitars, think you should sell them?", "r");
            evi4.setupWin("Guitar", 200, 3, 50);
            ALLEVENTS.Add(evi4);
            EventItem evi5 = new EventItem("Your friend from high school wants to get into the fruit industry. Want to work with him?", "co");
            evi5.setupWin("Apples", 3, 100, 50);
            ALLEVENTS.Add(evi5);
        }
        public static void getRandEvent()
        {
            Console.Clear();
            Random rnd = new Random();
            int randeventnum = rnd.Next(0, (ALLEVENTS.Count));
            ALLEVENTS[randeventnum].showsetup();
            Console.WriteLine("Press any key to return.");
            Console.ReadKey();
        }
        public static void help()
        {
            Console.Clear();
            Console.WriteLine("Crapitalism is a game all about making money. Creating products and selling them is one of the most straight forward ways of doing this. Another way to make some extra cash is by triggering a random event. A random event will test your character to see if their stats are strong enough to pass the test. If passed you'll win money or product. If lost you'll loose money. Good luck and invest well!");
            Console.WriteLine("Press enter to return to the game.");
            Console.ReadKey();
        }
    }
}
