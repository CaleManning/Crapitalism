﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Xml.Schema;
using System.Collections;

namespace Manning_AdventApp_062620_v1
{
    class Buisness
    {
        string name = "";
        public double bank = 100;
        double income = 0;
        List<Product> inventory = new List<Product>();
        public Buisness()
        {

        }
        //get
        public string getName()
        {
            return name;
        }
        public double getBankDouble()
        {
            return bank;
        }
        public string getBankString()
        {
            if (bank >= 0)
            {
                return bank.ToString("C", CultureInfo.CurrentCulture);
            }
            else
            {
                return ("-" + (bank*-1).ToString("C", CultureInfo.CurrentCulture));
            }
        }
        public string getIncomeStr()
        {
            return income.ToString("C", CultureInfo.CurrentCulture);
        }
        public double getIncome()
        {
            return income;
        }
        //set
        public void setName(string w)
        {
            name = w;
        }
        //special
        public void buisnessHeader()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("============================================================================");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write($"          {name}");
            if (bank > 0)
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write("          " + getBankString());
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("          " + getBankString());
            }
            if(income > 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("          " + getIncomeStr());
            }
            else if(income < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("          " + getIncomeStr());
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("          " + getIncomeStr());
            }
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("============================================================================");
        }
        public void newProduct()
        {
            Console.Clear();
            var testread = "";
            Boolean breakpoint = false;
            String tempname = "";
            while (breakpoint != true)
            {
                Console.WriteLine("What would you like to call this product?");
                tempname = Console.ReadLine();
                if(tempname.Length > 0)
                {
                    breakpoint = true;
                }
                else
                {
                    Console.WriteLine("You have to call your product something! Press enter to try again.");
                    Console.ReadKey();
                }
                Console.Clear();
            }
            breakpoint = false;
            double tempPrice;
            while (breakpoint != true)
            {
                Console.WriteLine("How much would you like to sell it for, remember that it will cost you half of the sell price to produce the " + tempname);
                testread = Console.ReadLine();
                if(testread.Length > 0)
                {
                    if(isAllNumbers(testread) == true)
                    {
                        tempPrice = Convert.ToDouble(testread);
                        if (tempPrice > 0)
                        {
                            breakpoint = true;
                        }
                        else
                        {
                            Console.Write("Your item must cost more than $0. Press enter to try again.");
                            Console.ReadKey();
                        }
                    }
                    else
                    {
                        Console.WriteLine("I guess you don't have to be able to read to run a buisness! You can only charge customers numbers not letters! Press enter to try again.");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("You have to enter something for the sell price. Press enter to try again");
                    Console.ReadKey();
                }
                Console.Clear();
            }
            breakpoint = false;
            tempPrice = Convert.ToDouble(testread);
            int tempinvent = 0;
            while (breakpoint != true)
            {
                Console.WriteLine("How many unites would you like to buy?");
                testread = Console.ReadLine();
                if (testread.Length > 0)
                {
                    if (isAllNumbers(testread) == true)
                    {
                        tempinvent = Convert.ToInt32(testread);
                        if (tempinvent > 0)
                        {
                            breakpoint = true;
                        }
                        else
                        {
                            Console.WriteLine("You have to purchase at least 1 item. Press enter to try again.");
                            Console.ReadKey();
                        }
                    }
                    else
                    {
                        Console.WriteLine("I guess you don't have to be able to read to run a buisness! You can only buy numbers not letters! Press enter to try again.");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("You have to enter something for the item count. Press enter to try again");
                    Console.ReadKey();
                }
                Console.Clear();
            }
            double marketest = tempPrice;
            breakpoint = false;
            int tempm = 50;
            string resp = "";
            while (breakpoint != true)
            {
                Console.WriteLine("Would you like to market the " + tempname + " it will cost " + marketest.ToString("C", CultureInfo.CurrentCulture) + " (enter y or n)");
                resp = Console.ReadLine();
                if (resp.ToLower() == "y")
                {
                    tempm = 100;
                    breakpoint = true;
                }
                else if (resp.ToLower() == "n")
                {
                    breakpoint = true;
                }
                else
                {
                    Console.WriteLine("You have to pick either y or n. Press enter to try again.");
                    Console.ReadKey();
                }
                Console.Clear();
            }
            if (Program.playerBuis.getBankDouble() >= (tempinvent * (tempPrice/2)))
            {
                Console.WriteLine("Congrats on your new Product! It has been added to your inventory");
                Product product = new Product(tempname, tempPrice, tempinvent, tempm);
                if(tempm == 100)
                {
                    Program.playerBuis.bank -= marketest;
                }
                Program.playerBuis.bank -= (tempinvent * (tempPrice / 2));
                Program.playerBuis.addProduct(product);
            }
            else
            {
                Console.WriteLine("Sorry you cannot afford this product.");
            }
            Console.WriteLine("Press any key to return.");
            Console.ReadKey();
        }
        public Boolean isAllNumbers(string s)
        {
            foreach(char c in s)
            {
                if (!Char.IsDigit(c))
                    return false;
            }
            return true;
        }
        public Boolean loseTest()
        {
            if (Program.playerBuis.bank <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void addProduct(Product x)
        {
            inventory.Add(x);
        }
        public void listInventory()
        {
            Console.Clear();
            Console.WriteLine(Program.playerBuis.getName() + "'s Inventory");
            for(int i = 0; i < inventory.Count; i++)
            {
                Console.WriteLine(inventory[i].getName() + " - Sell Price: " + inventory[i].getSellPrice() + " - Make Price: " + inventory[i].getMakePrice() + " - Owned: " + inventory[i].getInventory());
            }
            Console.WriteLine("Press any key to return.");
            Console.ReadKey();
        }
        public void sellInvent()
        {
            Console.Clear();
            Console.WriteLine("Sales from this turn");
            List<int> markedNums = new List<int>();
            Random rnd = new Random();
            income = 0;
            double MoneyMade = 0;
            for (int i = 0; i < inventory.Count; i++)
            {
                Console.WriteLine(inventory[i].getName() + " Items Sold:");
                int itemsSold = rnd.Next(1, inventory[i].getInventory());
                if(inventory[i].getMarketability() == 100)
                {
                    double tempSell = Convert.ToDouble(itemsSold) / .2;
                    itemsSold = Convert.ToInt32(tempSell);
                }
                if(itemsSold >= inventory[i].getInventory())
                {
                    MoneyMade = Convert.ToDouble(inventory[i].getInventory()) * inventory[i].getSellPrice();
                    Console.WriteLine("Sold Items: " + inventory[i].getInventory() + " - Total Made: " + MoneyMade.ToString("C", CultureInfo.CurrentCulture));
                    markedNums.Add(i);
                }
                else
                {
                    MoneyMade = itemsSold * inventory[i].getSellPrice();
                    Console.WriteLine("Sold Items: " + itemsSold + " - Total Made: " + MoneyMade.ToString("C", CultureInfo.CurrentCulture));
                    inventory[i].invent -= itemsSold;
                }
                income += MoneyMade;
                bank += MoneyMade;
            }
            for(int j = markedNums.Count-1; j > -1; j--)
            {
                inventory.RemoveAt(markedNums[j]);
            }
            Console.WriteLine("Press any key to return.");
            Console.ReadKey();
        }
    }
}
