﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Runtime.CompilerServices;
using System.Text;

namespace Manning_AdventApp_062620_v1
{
    class EventMoney
    {
        public String setup = "";
        double reward = 0;
        public String traitTest = "";
        public EventMoney(string su, double rw, string tt)
        {
            setup = su;
            reward = rw;
            traitTest = tt;
        }
        public virtual void showsetup()
        {
            Console.Clear();
            Console.WriteLine(setup);
            Boolean breakansw = false;
            String resp = "";
            while(breakansw != true)
            {
                Console.WriteLine("Please enter y or n to accept or turn down this offer.");
                resp = Console.ReadLine();
                if(resp == "y")
                {
                    breakansw = true;
                    if(traitRandomTest(traitTest) == true)
                    {
                        Console.WriteLine("Congrats you passed the trait test and were rewarded " + reward);
                        Program.playerBuis.bank += reward;
                    }
                    else
                    {
                        Console.WriteLine("Sorry you failed the trait test and lost " + reward);
                        Program.playerBuis.bank -= reward;
                    }
                }
                else if(resp == "n")
                {
                    breakansw = true;
                }
                else
                {
                    Console.WriteLine("Please Enter a Valid response.");
                }
            }
        }
        public Boolean traitRandomTest(string tr)
        {
            int ta = 0;
            //r = ruthlessness, co = collaberative, i = intelligence, ch = charisma
            if(tr == "r")
            {
                ta = Program.playerCharacter.ruthlessness;
            }
            else if (tr == "co")
            {
                ta = Program.playerCharacter.collaberative;
            }
            else if (tr == "i")
            {
                ta = Program.playerCharacter.intelligence;
            }
            else if (tr == "ch")
            {
                ta = Program.playerCharacter.charisma;
            }
            //return true if passed false if failed.
            Random rnd = new Random();
            int testnum = rnd.Next(1, 10);
            if(ta < testnum)
            {
                return false;
            }
            else
            {
                return true;
            }

        }
    }
}
