﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace Manning_AdventApp_062620_v1
{
    class EventItem : EventMoney
    {
        Product Win = new Product("",0,0,0);
        public EventItem(string su, string tt) : base("", 0, "")
        {
            setup = su;
            traitTest = tt;
        }
        public void setupWin(string n, double p, int i, int m)
        {
            Win.productSetup(n, p, i, m);
        }
        public override void showsetup()
        {
            Console.Clear();
            Console.WriteLine(setup);
            Boolean breakansw = false;
            String resp = "";
            while (breakansw != true)
            {
                Console.WriteLine("Please enter y or n to accept or turn down this offer.");
                resp = Console.ReadLine();
                if (resp == "y")
                {
                    breakansw = true;
                    if (traitRandomTest(traitTest) == true)
                    {
                        Console.WriteLine("Congrats you passed the trait test and were rewarded " + Win.getInventory() + " " + Win.getName() + "(s)");
                        Program.playerBuis.addProduct(Win);
                    }
                    else
                    {
                        Console.WriteLine("Sorry you failed the trait test and did not get " + Win.getInventory() + " " + Win.getName() + "(s)");
                    }
                }
                else if (resp == "n")
                {
                    breakansw = true;
                }
                else
                {
                    Console.WriteLine("Please Enter a Valid response.");
                }
            }
        }
    }
}
